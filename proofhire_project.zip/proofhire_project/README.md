# ProofHire — Evidence-first placements

A responsive, static front-end prototype for a placement platform. It demonstrates student opportunity discovery, explainable skill-fit scores, an application tracker, an evidence-led resume editor, an evidence ledger, and a recruiter shortlist.

## Run locally

1. Extract this folder.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Use the sidebar to explore each module.

The app has no build step and no external JavaScript/CSS dependencies. Demo edits are saved in the browser's local storage when available. They remain on that browser/device only; clearing browser storage removes them.

## Important prototype limitations

- Job listings, candidate records, fit scores, evidence, and application history are illustrative demo data. They are not real job openings or real candidate evaluations.
- The app does not have a server, authentication, a shared database, real-time job feeds, email notifications, or verified GitHub/recruiter integrations.
- Do not enter sensitive personal information into this demo. Do not use demo candidate rankings to make actual hiring decisions.
- A production deployment requires a secure backend, authorization and role-based access, validated APIs, privacy/consent workflows, audit logs, accessibility testing, and security review.

## Publish free with GitHub Pages

Google Sites does not directly host an arbitrary uploaded HTML/CSS/JS project as a normal website. The simplest free route is to publish this static project on GitHub Pages, then optionally embed the published URL in a Google Site.

1. Sign in to GitHub and create a **new public repository** named `proofhire` (or another name).
2. Upload `index.html` and `README.md` from this folder to the repository root. Do not upload the ZIP itself as the website source.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment**, choose **Deploy from a branch**; select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish. The URL is normally `https://YOUR-USERNAME.github.io/proofhire/` (use the exact URL GitHub displays).
6. Test the published URL on desktop and mobile, including every navigation tab and key buttons.

## Embed in Google Sites (optional)

1. Publish the site first using the GitHub Pages steps above.
2. Open Google Sites and edit your site.
3. Choose **Insert → Embed → By URL**, paste the published HTTPS URL, and insert it.
4. Resize the embed area and publish the Google Site. If the embed is blocked or awkward on mobile, link to the GitHub Pages site instead.

You must sign in and complete publishing in your own GitHub/Google accounts. This package does not publish anything automatically.

## Before a real public launch

Replace demo listings with clearly sourced real openings, add a secure backend and database, implement user accounts and permissions, add reporting/moderation and consent controls, make fit-score calculations explainable and audited for bias, add proper privacy/terms pages, and test with real users. Never label a skill or candidate as verified without a defined verification process.
